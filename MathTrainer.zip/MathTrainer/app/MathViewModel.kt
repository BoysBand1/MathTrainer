package com.example.mathtrainer

import androidx.lifecycle.ViewModel
import kotlin.random.Random

class MathViewModel : ViewModel() {
    private var operand1: Int = 0
    private var operand2: Int = 0
    private var operator: Char = '+'

    var userAnswer: String = ""
    var isStartEnabled: Boolean = true
    var isAnswerInputEnabled: Boolean = false
    var isCheckEnabled: Boolean = false
    var isChecked: Boolean = false
    var isAnswerCorrect: Boolean = false
    var correctCount: Int = 0
    var wrongCount: Int = 0

    fun generateExample() {
        operand1 = Random.nextInt(10, 100)
        operand2 = Random.nextInt(10, 100)

        val operators = charArrayOf('+', '-', '*', '/')
        operator = operators[Random.nextInt(4)]

        if (operator == '/') {
            while (operand1 % operand2 != 0) {
                operand2 = Random.nextInt(10, 100)
            }
        }

        isStartEnabled = false
        isAnswerInputEnabled = true
        isCheckEnabled = false
        isChecked = false
        userAnswer = ""
    }

    fun checkAnswer() {
        val userAnswerInt = userAnswer.toIntOrNull() ?: 0
        val correctAnswer = calculateCorrectAnswer()

        isChecked = true
        isAnswerCorrect = userAnswerInt == correctAnswer

        if (isAnswerCorrect) {
            correctCount++
        } else {
            wrongCount++
        }

        isStartEnabled = true
        isAnswerInputEnabled = false
        isCheckEnabled = false
    }

    private fun calculateCorrectAnswer(): Int {
        return when (operator) {
            '+' -> operand1 + operand2
            '-' -> operand1 - operand2
            '*' -> operand1 * operand2
            '/' -> operand1 / operand2
            else -> 0
        }
    }

    fun getExampleText(): String {
        return if (!isStartEnabled) {
            "$operand1 $operator $operand2 = ?"
        } else {
            "Нажмите СТАРТ"
        }
    }

    fun getPercentageText(): String {
        val total = correctCount + wrongCount
        return if (total > 0) {
            val percentage = (correctCount.toDouble() / total) * 100
            "%.2f%%".format(percentage)
        } else {
            "0.00%"
        }
    }
}