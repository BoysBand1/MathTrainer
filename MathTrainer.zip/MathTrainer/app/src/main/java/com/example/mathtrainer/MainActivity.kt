package com.example.mathtrainer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private val TAG = "MathTrainer"

    private lateinit var tvExample: TextView
    private lateinit var etAnswer: EditText
    private lateinit var btnStart: Button
    private lateinit var btnCheck: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Log.d(TAG, "onCreate: Приложение запускается")

        try {
            setContentView(R.layout.activity_main)
            Log.d(TAG, "setContentView: успешно")
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка setContentView: ${e.message}")
            return
        }

        try {
            initViews()
            Log.d(TAG, "initViews: успешно")
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка initViews: ${e.message}")
            return
        }

        setupClickListeners()
        Log.d(TAG, "Приложение успешно запущено")
    }

    private fun initViews() {
        tvExample = findViewById(R.id.tvExample)
        etAnswer = findViewById(R.id.etAnswer)
        btnStart = findViewById(R.id.btnStart)
        btnCheck = findViewById(R.id.btnCheck)

        tvExample.text = "Готов к работе!"
        btnStart.isEnabled = true
        btnCheck.isEnabled = false
    }

    private fun setupClickListeners() {
        btnStart.setOnClickListener {
            tvExample.text = "Пример: 10 + 20 = ?"
            etAnswer.isEnabled = true
            btnCheck.isEnabled = true
            btnStart.isEnabled = false

        }

        btnCheck.setOnClickListener {
            val answer = etAnswer.text.toString()
            if (answer == "30") {
                tvExample.text = "Правильно! ✅"
            } else {
                tvExample.text = "Неправильно! ❌"
            }
            etAnswer.isEnabled = false
            btnCheck.isEnabled = false
            btnStart.isEnabled = true
        }
    }
}